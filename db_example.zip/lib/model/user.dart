class User {
  int? id;
  String? name;
  String? account;
  String? password;
  int? status;

  User({this.id, this.name, this.account, this.password, this.status});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'account': account,
      'password': password,
      'status': status,
    };
  }

  User.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    name = map['name'];
    account = map['account'];
    password = map['password'];
    status = map['status'];
  }
}
