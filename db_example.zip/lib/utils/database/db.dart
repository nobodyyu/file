import 'package:apikeeper/model/user.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DB {
  final String dbName = "my_database.db";

  // Singleton pattern
  static final DB _db = DB._internal();
  factory DB() => _db;
  DB._internal();

  static Database? _database;
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasePath = await getDatabasesPath();
    final path = join(databasePath, dbName);

    return await openDatabase(
      path,
      onCreate: _onCreate,
      version: 1,
      onConfigure: (db) async => await db.execute('PRAGMA foreign_keys = ON'),
    );
  }

  //第一次建立資料庫時，建立一個表格來儲存品種和一個表格來儲存使用者
  Future<void> _onCreate(Database db, int version) async {
    await db.execute(
      'CREATE TABLE user(id INTEGER PRIMARY KEY, name TEXT, account TEXT,password TEXT, status INTEGER)',
    );
  }
}

//User
extension UserExt on DB {
  Future<void> insertUser(User user) async {
    final db = await DB().database;

    await db.insert(
      'user',
      user.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateUser(User user) async {
    final db = await DB().database;

    await db.update(
      'user',
      user.toMap(),
      where: 'id = ?',
      whereArgs: [user.id],
    );
  }

  Future<void> deleteUser(int id) async {
    final db = await DB().database;

    await db.delete(
      'user',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<User?> getUser(int id) async {
    final db = await DB().database;

    var rtn = await db.query(
      'user',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (rtn.isNotEmpty) {
      return User.fromMap(rtn[0]);
    }
    return null;
  }

  Future<List<User>> getAllUser() async {
    final db = await DB().database;

    var rtn = await db.query(
      'user',
    );

    List<User> listUser = [];
    for (var e in rtn) {
      listUser.add(User.fromMap(e));
    }
    return listUser;
  }
}
