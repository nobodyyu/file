import 'package:apikeeper/model/user.dart';
import 'package:apikeeper/utils/database/db.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Api Keeper',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'API Keeper'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'User Test',
            ),
            ElevatedButton(
                onPressed: () {
                  DB().insertUser(User(
                    name: "John",
                    account: "john",
                    password: "1234",
                    status: 1,
                  ));
                },
                child: const Text("Add John into User")),
            const SizedBox(height: 10),
            ElevatedButton(
                onPressed: () async {
                  List<User> listUser = await DB().getAllUser();
                  debugPrint(listUser.length.toString());
                },
                child: const Text("Get All User")),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
